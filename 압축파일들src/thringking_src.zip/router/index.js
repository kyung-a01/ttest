import { createRouter, createWebHistory } from 'vue-router'
import ProductList from '../views/ProductList.vue'
import main from '../views/2_main.vue'
import mypage from '../views/2_mypage.vue'
import cafe from '../views/2_cafe.vue'
import login from '../views/2_login.vue'
import ProductDetail from '../views/ProductDetail.vue'
import ProductCreate from '../views/ProductCreate.vue'


const routes = [
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path: '/',
    name: 'home',
    component: main
  },
  {
    path: '/mypage',
    name: 'mypage',
    component: mypage
  },
  {
    path: '/cafe',
    name: 'cafe',
    component: cafe
  },
  {
    path: '/login',
    name: 'login',
    component: login
  },



  /* {
    path: '/detail',
    name: 'ProductDetail',
    component: ProductDetail
  },
  {
    path: '/Create',
    name: 'ProductCreate',
    component: ProductCreate
  } */
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
