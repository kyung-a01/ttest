import {
    createStore
} from 'vuex';

 

const store = createStore({
    state() {
        return {
            count:0,
            cart: [{
                product_id : 34534,
                product_name : "아이폰 거치대",
                category: "A-123124"
            },
            {
                product_id : 45345,
                product_name : "삼성 충전기",
                category: "A-018384"
            },
            {
                product_id : 95005,
                product_name : "샤오미 충전기",
                category: "A-99984"
            }]
        }
    },
    getters: { //state의 값을 가지고 특정 로직을 실행시켜 컴포넌트에서 getters를 사용할 수 있음
        cartCount: (state) => {
            return state.cart.length;
        }
    },
    mutations: {//increment에 1씩증가 시키기 위한 함수. state에 정의된ㄷ 변수를 직접 변경하기 위해 사용됨
        increment(state) {
            state.count++
        }
    },
    actions: { //mutations를 실행시키는 역할
        increment(context) {
            context.commit('increment')//commit()함수를 1씩 이용해 1씩 증가하는 함수
        }
    }
})

export default store;