<template>
<div>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/databinding">Data Binding</router-link> |
    <router-link to="/databindinghtml">Data Binding HTML</router-link> |
    <router-link to="/DataBindingInputText">Data-Binding-Input-Text</router-link> |
     <router-link to="/DataBindingInputNumber">Data-Binding-Input-Number</router-link> |
    <router-link to="/DataBindingtextarea">Data-Binding-텍스트</router-link> |
    <router-link to="/DataBindingSelect">Data-Binding-셀렉트</router-link> |
    <router-link to="/DataBindingCheckbox">Data-Binding-체크박스</router-link> |
    <router-link to="/DataBindingCheckbox2">Data-Binding-(다중)체크박스2</router-link> |
    <router-link to="/DataBindingRadio">Data-Binding-라디오</router-link> |
    <router-link to="/DataBindingAttribute">Data-Binding-이미지</router-link> |
    <router-link to="/DataBindingButton">Data-Binding-버튼</router-link> |
    <router-link to="/DataBindingClass">Data-Binding-클래스</router-link> |
    <router-link to="/DataBindingClass2">Data-Binding-클래스2</router-link> |
    <router-link to="/DataBindingStyle">Data-Binding-스타일</router-link> |
    <router-link to="/DataBindingStyle2">Data-Binding-스타일2</router-link> |
    <router-link to="/DataBindingList">Data-Binding-리스트</router-link> |
    <router-link to="/RenderingVif">렌더링 V-if</router-link> |
    <router-link to="/EventClick">event클릭</router-link> |
    <router-link to="/EventChange">event체인지</router-link> |
    <router-link to="/Computed">computed</router-link> |
    <router-link to="/Watch">watch</router-link> |
    <router-link to="/Watch2">watch2</router-link> |
    <router-link to="/DataBindingList2">데이타바인딩리스트2</router-link> |
    <router-link to="/nested">nested컴포넌트</router-link> |
    <router-link to="/parent">parent컴포넌트</router-link> |<!-- 부모에서자식으로 이벤트 발생시키기-->
    <router-link to="/parent2">parent컴포넌트2</router-link> | <!-- 부모에서 자식으로 함수 직접 호출하기 -->
    <router-link to="/parent3">parent컴포넌트3</router-link> |
    <!-- 부모가 자식의 데이터 옵션값 직접 변경 -->
    <router-link to="/parent4">parent컴포넌트4</router-link> |
    <router-link to="/parent5">parent컴포넌트5</router-link> |
    <router-link to="/slotuse">slot-use모달레이아웃</router-link> |
    <router-link to="/store">store</router-link> |
    <router-link to="/kakaologin">카카오로그인</router-link> |
    
   
    
  
  
  </nav>
     <router-view />
</div>
</template>

<script>
export default {
  name: 'App',
  components: {
  
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

nav{margin-bottom: 50px;}

</style>
