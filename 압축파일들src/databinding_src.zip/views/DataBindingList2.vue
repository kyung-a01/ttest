<template>
    <div>
        <table>
            <thead>
                <tr>
                    <th>제품명</th>
                    <th>가격</th>
                    <th>카테고리</th>
                    <th>배송료</th>
                </tr>
            </thead>
            <tbody>
                <!-- v-for = (배열의 아이템,인덱스) in 데이터의 배열이름-->
                <tr :key="i" v-for="(product,i) in productList">
                    <td>{{product.product_name}}</td>
                    <td>{{product.price}}</td>
                    <td>{{product.category}}</td>
                    <td>{{product.sale_price}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
export default {
    data(){
        return{
            productList : []
         }
    },
    created () {
        this.getList()
    },
    methods: {
        async getList (){
            this.productList = await this.$api('https://643a6c73-b3ae-4edf-8390-061a1b4cea65.mock.pstmn.io/list', 'get')
        }
    }
}
</script>

<style scoped>  
    table{
        font-family:arial,sans-serif;
        border-collapse: collapse;
        width: 100%;
    }
    td,th{
        border: 1px solid #ddd;
        text-align: left;
        padding: 8px;
    }
</style>