<template>
<div>
    <!-- 버튼에 클릭이벤트 추가하고 클릭이 발생하면 increaseCounter함수가 호출되도록 -->
    <button type="button" @click="increaseCounter">Add 1</button>
    <p>The counter is : {{ counter }}</p>

    <button type="button" @click="setCount(7)">Set 7</button>
    <p>The counter is : {{ counter2 }}</p>

    <button type="button" v-on:click="one(),two()">Click</button>
</div>
</template>

<script>
export default {
    data(){
        return{
            counter: 0,
            counter2: 0
        }
    },
    methods : {
        increaseCounter(){
            this.counter = this.counter +1//1씩 증가시키는 함수
        },
        setCount (counter2){
            this.counter2 = counter2
        },
        one(){
            alert('one')
        },
        two(){
            alert('two')
        }
    }
}
</script>

<style>


</style>