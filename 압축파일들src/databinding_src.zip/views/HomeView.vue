<template> <!-- view에 해당하는 html코드를 작성하는 영역 -->
  <div>
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>


</script>