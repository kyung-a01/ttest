<template>
  <div>

  </div>
</template>

<script>
export default {
    data() {
        return {
            msg : '자식 컴포넌트로부터 보내는 메세지'
        };
    },
    mounted() {
        this.$emit('send-message', this.msg) //data()의 내용을 가져오려면 this.를 붙여야함.
    }
}
</script>

<style>

</style>