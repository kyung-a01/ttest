<template>
<!-- 체크박스에서는 v-model이 체크박스의 value 속성이 아닌 checked 속성을 사용하기때문에 value속성에 데이터 바인딩을 하려면 v-model이 아닌 v-bind:value를 사용해야함 -->
  <div>
    <label><input type="checkbox" v-bind:value="checkValue1" v-model="checked"> 서울 </label>
    <label><input type="checkbox" v-bind:value="checkValue2" v-model="checked"> 부산 </label>
    <label><input type="checkbox" v-bind:value="checkValue3" v-model="checked"> 제주 </label>
    
    <br>
    <span>체크한 지역 : {{checked}}</span>
    
  </div>
</template>

<script>
export default {
    data(){
        return{
            checked: [],
            checkValue1: '서울',
            checkValue2: '부산',
            checkValue3: '제주'
         }
    }
}
</script>

<style>

</style>