<template>
    <div>
        <div>{{htmlString}}</div>
        <div v-html="htmlString"></div>
    </div>
</template>

<script>
export default {
    data() {
        return{
            htmlString : '<p style="color:red;">This is red htmlstring</p>'
        }
    }
}
</script>

<style>

</style>

 