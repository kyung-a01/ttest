<template>
  <div>
      <!-- 부모 컴포넌트에서 자식 컴포넌트의 버튼을 클릭하는 이벤트 발생시키기 -->
      <child-component @send-message="sendMessage" ref="child_component" />
      <!-- ref=""를 지정하면 vue컴포넌트의 함수에서 this.$ref를 통해 접근 가능 -->
  </div>
</template>

<script>
import ChildComponent from './ChildComponent.vue';

export default {
    components : {ChildComponent},
    mounted() {
        this.$refs.child_component.$refs.btn.click();       
    }
}
</script>

<style>

</style>