<template>
<!-- change이벤트가 가장 많이 사용되는 HTML태그는 select 이다.
사용자가 select에서 옵션을 바꿀 때마다 change이벤트가 발생됨.
change 이벤트는 @change="메소드명"으로 사용함. -->
<div>
    <!-- 사용자가 select옵션을 바꿀 때마다 change이벤트가 발생되도록 -->
    <select v-model="selectedValue" @change="changeSelect">
        <option value="서울">서울</option>
        <option value="부산">부산</option>
        <option value="제주">제주</option>
    </select>
</div>
</template>

<script>
export default {
    data(){
        return{
           selectedValue: '' 
         }
    },
    methods : {
        changeSelect(){
            alert(this.selectedValue)
        }
    }
}
</script>

<style>


</style>