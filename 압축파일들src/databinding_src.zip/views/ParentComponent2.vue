<template>
    <div>
        <child-component @send-message="SendMessage" ref="child_component"/>
    </div>

</template>

<script>
import ChildComponent from './ChildComponent2.vue'
export default {
    components: {ChildComponent},
    mounted(){
        this.$refs.child_component.callFromParent();
    },
}
</script>

<style>

</style>