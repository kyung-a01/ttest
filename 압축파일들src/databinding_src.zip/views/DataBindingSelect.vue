<template>
  <div>
      <select v-model="city">
            <option value="02">서울</option>
            <option value="21">제주</option>
            <option value="064">부산</option>
             <option value="28">광주</option>
      </select>
  </div>
</template>

<script>
export default {
    data(){
        return{
           city: '064'
        }
    }
}
</script>

<style>

</style>