<template>
 <!-- value를 제외한 html객체이ㅡ 속성(attribute)에 데이터를 바인딩하기 위해 v-bind:디렉티브를 사용함 -->
 <!-- v-bind:디렉티브 는 v-bind를 생략하고 : 만으로도 사용 할 수 있음 -->
  <div>
    <label><input type="radio" v-bind:value="radioValue1" v-model="picked">서울</label>
    <label><input type="radio" v-bind:value="radioValue2" v-model="picked">부산</label>
    <label><input type="radio" v-bind:value="radioValue3" v-model="picked">제주</label>
    <br>
    <span>선택한 지역 : {{picked}}</span>
  </div>
</template>

<script>
export default {
    data(){
        return{
             picked: '',
             radioValue1: '서울',
             radioValue2: '부산',
             radioValue3: '제주'
         }
    }
}
</script>

<style>

</style>