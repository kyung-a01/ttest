<template>
 <!-- 제품 이미지, 사용자 프로필 사진처럼 이미지의 주소를 img객체의 src에 바인딩해야 하는 경우 -->
  <div>
      <img v-bind:src="imgSrc" />
  </div>
</template>

<script>
export default {
    data(){
        return{
            imgSrc : 'http://amnos135.dothome.co.kr/vue/plant.jpg'
         }
    }
}
</script>

<style>
 img{
     width: 300px;
 }
</style>