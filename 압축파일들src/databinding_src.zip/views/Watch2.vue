 <template>
<!-- computed와 watch 는 둘 다 vue인스턴스 내의 정의된 데이터 값에 변경이 일어나는지 감시하고, 변경될 때마다 정의된 함수가 실행됨
    차이점: computed는 기존에 정의된 데이터 값을 기반으로 새로운 데이터 값을 활용하기 위해 사용 된다면, watch는 watch에 정의된 데이터값 하나만 감시하기 위한 용도로 사용된다. -->
  <div>
      <h1>full Name:{{fullName}}</h1>
      <button type="button" @click="changeName">변경</button>
  </div>
</template>

<script>
export default {
    data() {
        return {
            firstName: 'Min Yeong',
            lastName: 'Kim',
            fullName: ''
        }
    },
    watch: {
        firstName (){
            this.fullName = this.firstName + ' ' +this.lastName
        },
        lastName(){
            this.fullName = this.firstName + ' ' +this.lastName
        }
    },
    methods: {
        changeName(){
            this.firstName = 'haeeeeeeeeeeeeeeee'
        }
    }
}
</script>

<style>

</style>