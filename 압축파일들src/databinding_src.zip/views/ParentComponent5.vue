<template>
  <div>
    <button type="button" @click="checkChild">자식컴포넌트 데이터 조회</button>
    <child-component ref="child_component" />
  </div>
</template>

<script>
import ChildComponent from './ChildComponent5.vue'

export default {
    components : {ChildComponent},
    computed:{ //computed를 이용해 msg의 값을 감지
        msg(){
            return this.$refs.child_component.msg;
        }
    },
    methods: {
        checkChild(){
            alert(this.msg);
        }
    }
}
</script>

<style>

</style>