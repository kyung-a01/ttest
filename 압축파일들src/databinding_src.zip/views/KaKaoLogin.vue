<template>
  <div>
    <a id="custom-login-btn" @click="kakaoLogin()">
        <img src="//k.kakaocdn.net/14/dn/btqCn0WEmI3/nijroPfbpCa4at5EIsjyf0/o.jpg" width="222" alt="">
    </a>
    <button type="button" @click="kakaoLogout">카카오로그아웃</button>
  </div>
</template>

<script>
export default {
  components:{},
  data() {
    return {
      code: '',
    };
  },
  mounted() {
    //Kakao.init("d6296b7ec4bc6060781b5307fa00f1d3");
  },
  methods: {
    kakaoLogin() {
      window.Kakao.Auth.login({
        scope : "profile_image, account_email, profile_nickname",
        success : this.getKaKaoAccount,
      });
    },
    getKaKaoAccount() {
      window.Kakao.API.request({
        url:"v2/user/me",
        success : (res) => {
          const kakao_account = res.kakao_account;//카카오계정으로 접근하기 위함
          const profile = kakao_account.profile_image;//카카오프로필
          const nickname = kakao_account.profile_nickname;//카카오닉네임
          const email = kakao_account.account_email;//카카오이메일
          
          console.log("profile", profile);
          console.log("nickname", nickname);
          console.log("email", email);
          //로그인처리 구현

          console.log(kakao_account);
          this.$store.commit("user",kakao_account);

          alert("로그인 성공ㅎ");
        },
        fail: (error) => {
          console.log(error);
        },
      });
    },
    kakaoLogout() {
      if (!window.Kakao.Auth.getAccessToken()){
        console.log("Not logged in.");
        return;
      }
      window.Kakao.Auth.logout((response) => {
        //로그아웃
        console.log("access token", window.Kakao.Auth.getAccessToken());
        console.log("log out:", response);
      });
    },
  },
};
</script>

<style>

</style>