import { createApp } from 'vue'
import App from './App.vue'
import router from './router.js'
import mixins from './mixins.js'
import store from './store.js'//vuex저장소 추가


/* createApp(App).mount('#app') */

const app = createApp(App)

app.use(router) //app.vue 에서 라우터가 사용될수있도록해줌
app.mixin(mixins)
app.mount('#app')
app.use(store)

window.Kakao.init("b45feedd7b7414bc08f5b5353b762ff8");
