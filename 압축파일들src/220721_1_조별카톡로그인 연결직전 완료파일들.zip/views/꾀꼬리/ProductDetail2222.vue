<template>
  <main>
  </main>
</template>


<style>
    main{
        width: 1000px;
        height: 1000px;
        background-color: red;
    }
</style>