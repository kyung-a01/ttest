<template>
  <main>
    <a href="#none">
      <img src="../assets/thrinking_logo.png" alt="로고" />
    </a>

    <div id="buttons">
      <!-- Modal 버튼 -->
      <button
        type="button"
        class="btn btn-primary"
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
      >
        로그인
      </button>

      <router-link to="/">
        <button
          type="button"
          class="btn btn-primary"
          data-bs-target="#exampleModal"
        >
          비회원
        </button>
      </router-link>
  
      <!-- Modal -->
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">SNS 로그인</h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">자체 로그인은 준비중입니다
            <!-- 부트스트랩 sns 로그인 -->
            <section style="margin-top:20px;">
                      <form style="display:flex; gap:10px;flex-direction:column;">
                      <a class="btn btn-primary btn-lg btn-block" style="background-color: #3b5998" href="#!"
                        role="button">
                        <i class="fab fa-facebook-f me-2"></i>Continue with Facebook
                      </a>
                      <a class="btn btn-primary btn-lg btn-block" style="background-color: #55acee" href="#!"
                        role="button">
                        <i class="fab fa-twitter me-2"></i>Continue with Twitter
                      </a>
                      <a class="btn btn-primary btn-lg btn-block" style="background-color: #fae100" href="#!"
                        role="button">
                        <i class="fab fa-twitter me-2"></i>Continue with KakaoTalk
                      </a>
                    </form>
            
            </section>
            <!-- 부트스트랩 sns 로그인 끝 -->







            </div>
            <div class="modal-footer">
              <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
              <label class="form-check-label" for="form1Example3">자동 로그인</label>
            </div>
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                완료
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- Modal 버튼 끝-->

    </div>
    
  </main>
</template>


<style scope>

dl,
ol,
ul {
  padding-left: 0;
  margin: 0;
}

main {
  width: 100%;
  height: 100%;
  background-color: #e9e9e9;
  color: black;
} 
main>a>img{
    max-width: 50%; 
    height:auto; 
    display: block;
  padding: 40px;
  margin: 0 auto;
}
@media screen and (min-width: 450px) {
 main>a>img {
      max-width: 40%; 
  }
}
/* 부트스트랩 모달팝업 */
 
button.btn.btn-primary{
   border: 1px solid #4f4f4f;
  background-color: #065f44;
  width: 200px;
  height: 50px;
}
button.btn.btn-secondary{
  background-color: #065f44;

}


#buttons{
  display: flex;
  flex-wrap: wrap;
    flex-direction: column;
    align-content: space-around;
    gap: 5px;
}
/* 부트스트랩 모달팝업 */

</style>