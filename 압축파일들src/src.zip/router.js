import { createWebHistory, createRouter } from "vue-router"
import DataBinding from './views/DataBinding.vue'

const routes = [

  {
    path: '/databinding', //경로
    name: 'DataBinding',
    component: DataBinding //import해온 컴포넌트,
  }

];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
});

export default router; //위에서 import한 파일들을 내보내기