<template>
<div id="app">
  <nav>      
	<router-link to="/databinding">Data Binding</router-link> 
  </nav>
  
    <router-view />

</div>
  
</template>

<script>
export default {
  name: 'App',
  components: {

  }
}
</script>