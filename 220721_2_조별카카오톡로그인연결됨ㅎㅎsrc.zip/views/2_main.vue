<template>
  <main>



    
    <img src="../assets/ad.jpg" alt="구글광고" />
    <div id="ranking">
      <ul>
        <li>
          <span>오늘의 음료</span>
          <span>마지막 갱신시각 오후 1시 30분</span>
        </li>
        <li>
          <ul class="today">
            <li>
              <div class="round_box">
                <img src="../assets/coffee_1.jpg" alt="1위음료사진" />
              </div>
              <p>
                <span>1위</span>
                <span>복숭아 아이스티</span>
                <span>스타벅스 (3m)</span>
              </p>
            </li>
           
            <li>
              <div class="round_box">
                <img src="../assets/coffee_2.png" alt="2위음료사진" />
              </div>
              <p>
                <span>2위</span>
                <span>자몽차</span>
                <span>딩동당동 (783m)</span>
              </p>
            </li>
            <li>
              <div class="round_box">
                <img src="../assets/coffee_3.jpg" alt="3위음료사진" />
              </div>
              <p>
                <span>3위</span>
                <span>구름을 품은 크림 카페라떼</span>
                <span>카페 어울림 (2km)</span>
              </p>
            </li>
          </ul>
        </li>
      </ul>
    </div>




    <!-- Modal 버튼 -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
       커피를 선택하세요
    </button>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            ...

            <!-- 검색바 -->
    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <!-- Font Awesome CSS -->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
      <!-- Actual search box -->
      <div class="form-group has-search">
        <span class="fa fa-search form-control-feedback"></span>
        <input type="text" class="form-control" placeholder="Search">
      </div>
      
      <!-- Another variation with a button -->
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search this blog">
        <div class="input-group-append">
          <button class="btn btn-secondary" type="button">
            <i class="fa fa-search"></i>
          </button>
        </div>
      </div>
    <!-- 검색바끝 -->
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
        </div>
      </div>
    </div>
     <!-- Modal 버튼 끝-->




  </main>
</template>


<style scoped>

@font-face {
    font-family: 'GowunDodum-Regular';
    src: url('https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_2108@1.1/GowunDodum-Regular.woff') format('woff');
    font-weight: normal;
    font-style: normal;
}

main {
  width: 100%;
  height: 600px;
/*   background-color: red;
 */  color: black;
 font-family: 'GowunDodum-Regular';
}
main > img {
  width: 100%;
}

#ranking > ul {
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-evenly;
  flex-direction: column;
  padding-left: 0;
}
#ranking > ul > li:first-child {
/*   background-color: pink;
 */  width: 100%;
  height: 80px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  flex-direction: row;
  align-items: baseline;
  padding: 0px 20px;
}
#ranking > ul > li:first-child > span:first-child {
  font-size: 25px;
  font-size: 6vw;
  color: #4f4f4f;
  line-height: 80px;
}
@media screen and (min-width: 450px) {
 #ranking > ul > li:first-child > span:first-child {
     font-size: 26px;
  }
}
#ranking > ul > li:first-child > span:last-child {
  font-size: 10px;
  color: #4f4f4f;
}
#ranking > ul > li:last-child > ul.today {
  width: 100%;
  height: 100%;
/*   background: #aaa;
 */  display: flex;
  justify-content: space-around;
  align-items: center;
  padding-left: 0;
}
#ranking > ul > li:last-child > ul.today li {
  width: 30%;
  height: 100%;
  padding: 10px 0px;
  overflow: hidden;
}

#ranking > ul > li:last-child > ul.today > li div.round_box {
  background: white;
  border-radius: 10px;
  overflow: hidden;
  margin: 0 auto;
  width: 30vw;
  height: 30vw;
}
#ranking > ul > li:last-child > ul.today > li div.round_box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
#ranking > ul > li:last-child > ul.today > li p {
  margin: 0 auto;
}
#ranking > ul > li:last-child > ul.today > li p span:nth-child(1) {
  display: block;
 font-size: 3vw;
}
#ranking > ul > li:last-child > ul.today > li p span:nth-child(2) {
  display: block;
 font-size: 3vw;
}

@media screen and (min-width: 450px) {
 #ranking > ul > li:last-child > ul.today > li p span:nth-child(1),
 #ranking > ul > li:last-child > ul.today > li p span:nth-child(2) {
     font-size: 16px;
  }
}
#ranking > ul > li:last-child > ul.today > li p span:last-child {
  display: block;
  font-size: 2vw;
}










/* 부트스트랩 모달팝업 */
 
button.btn.btn-primary{
   border: 1px solid #4f4f4f;
  background-color: #065f44;
}
/* 부트스트랩 모달팝업 */
/*부트스트랩검색바 */

.has-search .form-control {
    padding-left: 2.375rem;
}

.has-search .form-control-feedback {
    position: absolute;
    z-index: 2;
    display: block;
    width: 2.375rem;
    height: 2.375rem;
    line-height: 2.375rem;
    text-align: center;
    pointer-events: none;
    color: #aaa;
}
/*부트스트랩검색바 */

</style>