<template>       
    <main class="mt-3">
      <div class="container">
        <div class="row mb-2">
          <div class="col-12">
            <select class="form-select">
              <option selected></option>
              <option value="1">NEW10%</option>
              <option value="2">BEST</option>
              <option value="3">MADE</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="http://www.canmart.co.kr/shopimages/jason006/0790150027813.gif?1650418175" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">뱃살커버 밑단밴딩</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">컴퓨터</span>
                  <span class="badge bg-dark">악세사리</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">219,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="http://www.canmart.co.kr/shopimages/jason006/0790150027983.gif?1650500894" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">입어보면 아는 부드러움</h5>
                <p class="card-text">
                  <span class="badge bg-dark p-2 m-1">주문폭주</span>
                  <span class="badge bg-dark p-2 m-1">할인중</span>
                  <span class="badge bg-dark p-2 m-1">사봐라</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">119,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="http://www.canmart.co.kr/shopimages/jason006/0790150029293.gif?1653008806" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">좋은 소재로 선택하세요</h5>
                <p class="card-text">
                  <span class="badge bg-dark">사보라</span>
                  <span class="badge bg-dark">컴퓨터</span>
                  <span class="badge bg-dark">모니터</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">129,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="https://www.pickby.co.kr/shop/data/goods/1583211255510m0.png?cache_ver=202012274" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">라인프렌즈 젤리빔 초미니 스마트 프로젝터 JB-100</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">빔프로젝트</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">249,900원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="http://www.canmart.co.kr/shopimages/jason006/0790150029863.gif?1654214034" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">K70 RGB MK.2 BROWN 기계식 게이밍 키보드 갈축</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">컴퓨터</span>
                  <span class="badge bg-dark">악세사리</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">219,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="http://www.canmart.co.kr/shopimages/jason006/0790150029913.gif?1656464385" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">로지텍 MX VERTICAL 인체공학 무선 마우스</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">컴퓨터</span>
                  <span class="badge bg-dark">악세사리</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">119,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="https://www.pickby.co.kr/shop/data/goods/1592533764579m0.jpg?cache_ver=202012274" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">벤큐 모니터 BenQ GW2480</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">컴퓨터</span>
                  <span class="badge bg-dark">모니터</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">129,000원</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="card" style="width: 18rem;">
              <img src="https://www.pickby.co.kr/shop/data/goods/1583211255510m0.png?cache_ver=202012274" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">라인프렌즈 젤리빔 초미니 스마트 프로젝터 JB-100</h5>
                <p class="card-text">
                  <span class="badge bg-dark">전자제품</span>
                  <span class="badge bg-dark">빔프로젝트</span>
                </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-secondary">장바구니 담기</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary">주문하기</button>
                  </div>
                  <small class="text-dark">249,900원</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
</template>